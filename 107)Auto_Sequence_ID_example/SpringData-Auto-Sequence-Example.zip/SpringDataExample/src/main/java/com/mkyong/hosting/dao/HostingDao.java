package com.mkyong.hosting.dao;

import com.mkyong.hosting.model.Hosting;

public interface HostingDao {

	void save(Hosting hosting);

}